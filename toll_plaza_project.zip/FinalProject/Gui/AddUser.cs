﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Gui
{
    public partial class AddUser : Form
    {
        public AddUser()
        {
            InitializeComponent();
        }

        private void btnUserSave_Click(object sender, EventArgs e)
        {

            string empId = txtId.Text;
            string empname = txtUser.Text;
            string emppass = txtPass.Text;
            string empjoingdate = txtJoiningDate.Text;
            string emprole = txtRole.Text;
            SqlConnector sqlCon = new SqlConnector();
            string sql = "Insert into Table_1(EmpID,EmpNAME,EmpPASS,EmpJOINDATE,EmpROLE)" +
                "values('" + empId + "','" + empname + "','" + emppass + "','" + empjoingdate + "','" + emprole + "')";
            SqlCommand cmd = new SqlCommand(sql, sqlCon.Sqlcon);
            cmd.ExecuteNonQuery();
            sqlCon.Sqlcon.Close();
            MessageBox.Show("User Information save in the database : ");

            new AdminInfo().Show();
            this.Hide();



        }
    }
}
