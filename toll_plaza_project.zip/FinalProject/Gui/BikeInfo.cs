﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Globalization;

namespace Gui
{
    public partial class BikeInfo : Form
    {
        public BikeInfo()
        {
            InitializeComponent();
        }

        private void ok_Click(object sender, EventArgs e)
        {
            string bikeNumber = bNum.Text;
            string bikeDate = bDate.Text;
            string bikeTime = bTime.Text;
            double bikeMoneyReceived = Convert.ToDouble(bmoneyReceived.Text);
            string bikeVehicleType = "Bike";
            double toll = 200;
            double moneyBack = bikeMoneyReceived - toll;
            bMoneyBack.Text = Convert.ToString(moneyBack);
            double bikeMoneyBack = Convert.ToDouble(bMoneyBack.Text);

            SqlConnector sqlCon_obj = new SqlConnector();
            string sql = "Insert into Details(MoneyReceived,MoneyBack,CarNum,Date,Time,VehicleType) " +
                "values('" + bikeMoneyReceived + "','" + bikeMoneyBack + "','" + bikeNumber + "', '" + bikeDate + "', '" + bikeTime + "','"+ bikeVehicleType + "')";
            SqlCommand cmd = new SqlCommand(sql, sqlCon_obj.Sqlcon);
            cmd.ExecuteNonQuery();
            sqlCon_obj.Sqlcon.Close();

            DateTime BikeDate = bDate.Value;
            string day = BikeDate.ToString("dd");
            string month = BikeDate.ToString("MMMM");
            string year = BikeDate.ToString("yyyy");

            SqlConnector sqlCon_obj_1 = new SqlConnector();
            string sql_1 = "Insert Into incomeTable(Date,Month,Year,TollCollection)" +
                "values('" + day + "','" + month + "','" + year + "','" + toll + "')";
            SqlCommand cmd_1 = new SqlCommand(sql_1, sqlCon_obj_1.Sqlcon);
            cmd_1.ExecuteNonQuery();
            sqlCon_obj_1.Sqlcon.Close();

            Vehicle_Print vh = new Vehicle_Print();
            vh.txtVehTyp.Text = bikeVehicleType;
            vh.txtVehNum.Text = bikeNumber;
            vh.txtDat.Text = bikeDate;
            vh.txtTim.Text = bikeTime;
            vh.txtMonRec.Text = Convert.ToString(bikeMoneyReceived);
            vh.txtMonBac.Text = Convert.ToString(bikeMoneyBack);
            vh.Show();
            this.Hide();

        }

        private void textcarnumber_TextChanged(object sender, EventArgs e)
        {

        }

        private void textcarname_TextChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void carname_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
            VehicleInfo back = new VehicleInfo();
            back.Show();
        }
    }
}
