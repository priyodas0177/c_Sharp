﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Gui
{
    public partial class Remove : Form
    {
        public Remove()
        {
            InitializeComponent();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            string userName = txtUserName.Text;
            SqlConnector sqlcon_obj = new SqlConnector();
            string sql ="Delete from Table_1 where EmpNAME='"+userName+"'";

            SqlCommand cmd = new SqlCommand(sql, sqlcon_obj.Sqlcon);
            cmd.ExecuteNonQuery();
            sqlcon_obj.Sqlcon.Close();
            MessageBox.Show("User Deleted Successfully ! ");

            new AdminInfo().Show();
            this.Hide();
        }
    }
}
