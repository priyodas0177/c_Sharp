﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Globalization;

namespace Gui
{
    public partial class CarInfo : Form
    {
        public CarInfo()
        {
            InitializeComponent();
        }

        private void ok_Click(object sender, EventArgs e)
        {
            string carNumber = textCarNum.Text;
            string carDate = dateTimePicker.Text;
            string carTime = Time.Text;
            double carMoney = Convert.ToDouble(textMoneyRec.Text);            
            string carVehicleType = "Car";
            double toll = 500;
            double moneyBack = carMoney - toll;
            textMoneyBack.Text = Convert.ToString(moneyBack);
            double carMoneyBack = Convert.ToDouble(textMoneyBack.Text);

            SqlConnector sqlCon_obj = new SqlConnector();
            string sql = "Insert into Details(MoneyReceived,MoneyBack,CarNum,Date,Time,VehicleType) " +
                "values('" + carMoney+"','"+carMoneyBack+"','"+carNumber+"', '"+carDate+"', '"+carTime+"','"+carVehicleType+"')";
            
            SqlCommand cmd = new SqlCommand(sql, sqlCon_obj.Sqlcon);
            cmd.ExecuteNonQuery();
            sqlCon_obj.Sqlcon.Close();

            //hhhh
            DateTime CarDate_1 = dateTimePicker.Value;
            string day = CarDate_1.ToString("dd");
            string month = CarDate_1.ToString("MMMM");
            string year = CarDate_1.ToString("yyyy");
            
            SqlConnector sqlCon_obj_1 = new SqlConnector();
            string sql_1 = "Insert into incomeTable(Date,Month,Year,TollCollection) " +
                "values('" + day + "','" + month + "','" + year + "', '" + toll + "')";
            SqlCommand cmd_1 = new SqlCommand(sql_1, sqlCon_obj_1.Sqlcon);
            cmd_1.ExecuteNonQuery();
            sqlCon_obj_1.Sqlcon.Close();
            
            Vehicle_Print vh = new Vehicle_Print();           
            vh.txtVehTyp.Text = carVehicleType;
            vh.txtVehNum.Text = carNumber;
            vh.txtDat.Text = carDate;
            vh.txtTim.Text = carTime;
            vh.txtMonRec.Text = Convert.ToString(carMoney);
            vh.txtMonBac.Text = Convert.ToString(carMoneyBack);
            vh.Show();
            this.Hide();        
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
            VehicleInfo back = new VehicleInfo();
            back.Show();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
                       
        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {
          
        }
        private void textMoneyRec_TextChanged(object sender, EventArgs e)
        {
          
        }

        private void textMoneyBack_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void btn_moneyBack_Click(object sender, EventArgs e)
        {
            double Toll = 500;
            double moneyReceived = Convert.ToDouble(textMoneyRec.Text);
            double moneyBack = moneyReceived - Toll;
            textMoneyBack.Text = Convert.ToString(moneyBack);

        }
    }
}
