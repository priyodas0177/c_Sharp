﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//using System.Data;
using System.Data.SqlClient;
using System.Globalization;


namespace Gui
{
    /*class bb
    {
        //public static void Main(string[] args)
        {
            string carDate = "12/26/2022";

            DateTime myString = DateTime.ParseExact(carDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            int year = myString.Year;
            int month = myString.Month;
            int day = myString.Day;
            Console.WriteLine(" yy/mm/dd" + year, month, day);
        }*/

   // }
}