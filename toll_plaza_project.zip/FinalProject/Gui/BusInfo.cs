﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Globalization;

namespace Gui
{
    public partial class BusInfo : Form
    {
        public BusInfo()
        {
            InitializeComponent();
        }

        private void ok_Click(object sender, EventArgs e)
        {
            string busNumber =busNum.Text;
            string busDate =BusDat.Text;
            string busTime =BusT.Text;
            double busMoneyReceived = Convert.ToDouble(busMonRec.Text);
            string busVehicleType = "Bus";
            double toll =600;
            double moneyBack = busMoneyReceived - toll;
            busMonBac.Text = Convert.ToString(moneyBack);
            double busMoneyBack = Convert.ToDouble(busMonBac.Text);
            SqlConnector sqlCon_obj = new SqlConnector();
            string sql = "Insert into Details(MoneyReceived,MoneyBack,CarNum,Date,Time,VehicleType) " +
                "values('" + busMoneyReceived + "','" + busMoneyBack + "','" + busNumber + "', '" + busDate + "', '" + busTime + "','"+busVehicleType+"')";
            SqlCommand cmd = new SqlCommand(sql, sqlCon_obj.Sqlcon);
            cmd.ExecuteNonQuery();
            sqlCon_obj.Sqlcon.Close();

            DateTime BusDate = BusDat.Value;
            string day = BusDate.ToString("dd");
            string month = BusDate.ToString("MMMM");
            string year = BusDate.ToString("yyyy");

            SqlConnector sqlCon_obj1 = new SqlConnector();
            string sql_1 = "Insert into incomeTable(Date,Month,Year,TollCollection)" +
                "values('"+day+"','"+month+"','"+year+"','"+toll+"')";
            SqlCommand cmd_1 = new SqlCommand(sql_1,sqlCon_obj1.Sqlcon);
            cmd_1.ExecuteNonQuery();
            sqlCon_obj1.Sqlcon.Close();


            Vehicle_Print vh = new Vehicle_Print();
            vh.txtVehTyp.Text = busVehicleType;
            vh.txtVehNum.Text = busNumber;
            vh.txtDat.Text = busDate;
            vh.txtTim.Text = busTime;
            vh.txtMonRec.Text = Convert.ToString(busMoneyReceived);
            vh.txtMonBac.Text = Convert.ToString(busMoneyBack);
            vh.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
            VehicleInfo back = new VehicleInfo();
            back.Show();
        }

        private void textcarnumber_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
