﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Gui
{
    public partial class TruckInfo : Form
    {
        public TruckInfo()
        {
            InitializeComponent();
        }

        private void ok_Click(object sender, EventArgs e)
        {
            string TruckNumber = txtTnum.Text;
            string TruckDate = txtTDate.Text;
            string TruckTime = txtTtim.Text;
            double TruckMoneyReceived = Convert.ToDouble(txtTmonRec.Text);
            string TruckVehicleType = "Truck";
            double toll = 900;
            double moneyBack = TruckMoneyReceived - toll;
            txtTmonRec.Text = Convert.ToString(moneyBack);
            double TruckMoneyBack = Convert.ToDouble(txtTmonRec.Text);



            SqlConnector sqlCon_obj = new SqlConnector();
            string sql = "Insert into Details(MoneyReceived,MoneyBack,CarNum,Date,Time,VehicleType) " +
                "values('" + TruckMoneyReceived + "','" + TruckMoneyBack + "','" + TruckNumber + "', '" + TruckDate + "', '" + TruckTime + "','"+TruckVehicleType+"')";
            SqlCommand cmd = new SqlCommand(sql, sqlCon_obj.Sqlcon);
            cmd.ExecuteNonQuery();
            sqlCon_obj.Sqlcon.Close();

            DateTime truckDate = txtTDate.Value;
            string day = truckDate.ToString("dd");
            string month = truckDate.ToString("MMMM");
            string year=truckDate.ToString("yyyy");
            SqlConnector sqlCon_obj_1 = new SqlConnector();
            string sql_1 = "Insert into incomeTable(Date,Month,Year,TollCollection) " +
                "values('" + day + "','" + month + "','" + year + "', '" + toll + "')";

            SqlCommand cmd_1 = new SqlCommand(sql_1, sqlCon_obj_1.Sqlcon);
            cmd_1.ExecuteNonQuery();
            sqlCon_obj_1.Sqlcon.Close();

            Vehicle_Print vh = new Vehicle_Print();
            vh.txtVehTyp.Text = TruckVehicleType;
            vh.txtVehNum.Text = TruckNumber;
            vh.txtDat.Text = TruckDate;
            vh.txtTim.Text = TruckTime;
            vh.txtMonRec.Text = Convert.ToString(TruckMoneyReceived);
            vh.txtMonBac.Text = Convert.ToString(TruckMoneyBack);
            vh.Show();
            this.Hide();


            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
            VehicleInfo back = new VehicleInfo();
            back.Show();
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}
